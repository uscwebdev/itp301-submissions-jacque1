import React, { useState } from 'react';

export default function Form() {
//Create state variables 
  const [formElement, setFormElement] = useState({
    fullName: '',
    password: '',
    confirmPassword: '',
    email: '',
    phone: '',
    comments: '',
    termsAccepted: false,
  });

  const [formErrors, setFormErrors] = useState({
    fullName: '',
    password: '',
    confirmPassword: '',
    emailPhone: '',
    comments: '',
    termsAccepted: '',
  });

  //Event handler to handle onChange()
  function handleChange(e) {
    const { name, value, type, checked } = e.target;
  
    setFormElement(() => ({
      fullName: name === 'fullName' ? value : formElement.fullName,
      password: name === 'password' ? value : formElement.password,
      confirmPassword: name === 'confirmPassword' ? value : formElement.confirmPassword,
      email: name === 'email' ? value : formElement.email,
      phone: name === 'phone' ? value : formElement.phone,
      comments: name === 'comments' ? value : formElement.comments,
      termsAccepted: type === 'checkbox' ? checked : formElement.termsAccepted,
    }));
  }
  
  //Event handler to handle submit
  function handleFormSubmit(e) {
    e.preventDefault();
    const foundError = validateForm();

    if (!foundError) {
      alert('The form was successfully submitted.');
    }
  }
  function validateForm() {
    var error = false;
    const errors = {
      fullName: '',
      password: '',
      confirmPassword: '',
      emailPhone: '',
      comments: '',
      termsAccepted: '',
    };

    // Validation rules

    //Username
    if (formElement.fullName.length == 0) {
      error = true;
      errors.fullName = 'Name cannot be empty.';
    } else if (!formElement.fullName.includes(' ')) {
      error = true;
      errors.fullName = 'You must provide a full name.';
    }

    //Password
    if (formElement.password.length == 0) {
      error = true;
      errors.password = 'Password cannot be empty.';
    } else if (formElement.password.length < 5) {
      error = true;
      errors.password = 'Password must contain at least 5 characters.';
    } else if (!/[a-z]/.test(formElement.password) || !/[A-Z]/.test(formElement.password)) {
      error = true;
      errors.password = 'Password must contain uppercase and lowercase characters.';
    }

    //confirmPassword
    if (formElement.password != formElement.confirmPassword) {
      error = true;
      errors.confirmPassword = 'Passwords do not match.';
    }

    //Email and Phone
    if ((formElement.email.length == 0) && (formElement.phone.length == 0)) {
      error = true;
      errors.emailPhone = 'You must provide either email or phone.';
    }

    //Comments
    if (formElement.comments.length > 100) {
      error = true;
      errors.comments = 'Comments cannot exceed 100 characters.';
    }

    //TermAccepted
    if (!formElement.termsAccepted) {
      error = true;
      errors.termsAccepted = 'You must accept Terms & Conditions.';
    }

    setFormErrors(errors);
    return error;
  }
  

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleFormSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  name="fullName"
                  value={formElement.fullName}
                  onChange={handleChange}
                />
                <div className="text-danger">{formErrors.fullName}</div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  name="password"
                  value={formElement.password}
                  onChange={handleChange}
                />
                <div className="text-danger">{formErrors.password}</div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password-confirm" className="col-sm-2 col-form-label">
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password-confirm"
                  name="confirmPassword"
                  value={formElement.confirmPassword}
                  onChange={handleChange}
                />
                <div className="text-danger">{formErrors.confirmPassword}</div>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      name="email"
                      value={formElement.email}
                      onChange={handleChange}
                    />
                  </div>
                  <label htmlFor="phone" className="mt-sm-2 col-sm-2 col-form-label">
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      name="phone"
                      value={formElement.phone}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="text-danger">{formErrors.emailPhone}</div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  name="comments"
                  value={formElement.comments}
                  onChange={handleChange}
                ></textarea>
                <div className="text-danger">{formErrors.comments}</div>
                <small id="comment-count" className="form-text text-right">
                  {formElement.comments.length} / 100
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                    name="termsAccepted"
                    checked={formElement.termsAccepted}
                    onChange={handleChange}
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                </div>
                <div className="text-danger">{formErrors.termsAccepted}</div>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}





