import React from 'react';

function UserPost(props) {
  return (
    <div className="bar-review">
      <div className="bar-details">
        <img src={props.barPic} alt={props.barAlt} />
        <h4>{props.barName}</h4>
        <p>{props.subtitle}</p>
      </div>
      <div className="user-comment">
        <img src={props.profilePicSrc} alt={props.profilePicAlt} />
        <div className="comment-details">
          <h5>{props.username}</h5>
          <p>Date: {props.date}</p>
          <p>{props.content}</p>
          <a href={props.ins}>{props.insDescript}</a>
        </div>
      </div>
    </div>
  );
}

export default UserPost;
