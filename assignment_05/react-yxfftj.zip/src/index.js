import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));


root.render(
  <React.StrictMode>
    <h1>Sips of Hong Kong: Cocktail Bars Guide</h1>
    <p className="intro">
      Welcome to our guide to the finest cocktail bars in the vibrant city of
      Hong Kong! If you're a cocktail connoisseur or simply looking to savor
      delicious libations in a stunning setting, you're in for a treat. Hong
      Kong's cocktail scene is a testament to the city's cosmopolitan spirit,
      some of which have earned coveted spots on{' '}
      <a href="https://www.worlds50bestbars.com/asia/list/1-50">
        Asia's 50 Best Bars.
      </a>
    </p>
    <p className="intro">
      In this curated collection, we invite you to explore the hidden gems and
      renowned establishments that make up the city's cocktail landscape.
      Whether you're in search of classic concoctions, innovative mixology, or
      breathtaking views of the city's skyline, Hong Kong has it all.
    </p>

    <div className="thumbnails">
      <img
        src="https://media.timeout.com/images/105639464/1920/1080/image.jpg"
        alt="HK Skyline"
      />

      <img
        src="https://www.travelandleisure.com/thmb/jamYDc6tmUpQP0W1qGULWC9ttr4=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/hong-kong-china-HONGKONGTG0721-c513469a8c7c4c27b67f6a5ea2fadc2b.jpg"
        alt="HK Street View"
      />
    </div>

    <p className="intro">
      Each bar on our list has been handpicked for its exceptional drinks,
      skilled bartenders, and unique ambiance. Join us on a journey through the
      bustling streets of Hong Kong as we raise our glasses to the city's
      vibrant cocktail culture. So, whether you're a local looking for a new
      haunt or a traveler seeking a memorable night out, let us be your guide to
      the world of cocktails in Hong Kong. Cheers!
    </p>

    <hr />
    <div className="bar-review">
      <div className="bar-details">
        <img
          src="https://cocktailsdistilled.com/wp-content/uploads/2021/05/Coa-Main-597x413.jpg"
          alt="COA Image"
        />
        <h4>COA</h4>
        <p>Agave Artistry in Every Sip</p>
      </div>
      <div className="user-comment">
        <img
          src="https://marketplace.canva.com/EAFWqgieqss/1/0/1600w/canva-blue-and-peach-gradient-facebook-profile-picture-oBy0jAd4JFY.jpg"
          alt="User 1 Profile"
        />
        <div className="comment-details">
          <h5>Olivia Johnson</h5>
          <p>Date: September 20, 2023</p>
          <p>
            Launched in 2017 by bartender-owner Jay Khan, COA is a shrine to all
            things agave and houses an extensive collection of 200 handcrafted
            Latin American liquids including tequila, mezcal, raicilla, sotol
            and more.
          </p>
          <p>
            The bar serves a perfect blend of subtle agave education, relaxed
            vibes and a simply fantastic drinks list. This, combined with the
            great work they have been doing to support their community
            throughout the pandemic, makes COA a bona fide no.1 this year.
          </p>
          <a href="https://www.instagram.com/COAhongkong/">
            Visit Coa's Instagram
          </a>
        </div>
      </div>
    </div>

    <div className="bar-review">
      <div className="bar-details">
        <img
          src="https://media-cdn.tripadvisor.com/media/photo-s/1d/e1/70/82/argo.jpg"
          alt="ARGO Image"
        />
        <h4>ARGO</h4>
        <p>Harborfront Elegance in a Glass</p>
      </div>
      <div className="user-comment">
        <img
          src="https://marketplace.canva.com/EAFKOsBJAYc/1/0/1600w/canva-green-pink-simple-neon-tiktok-profile-picture-v3E-5AxhjNw.jpg"
          alt="User 2 Profile"
        />
        <div className="comment-details">
          <h5>Ava Brown</h5>
          <p>Date: July 2, 2023</p>
          <p>
            ARGO stands out for its stunning waterfront location and
            sophisticated cocktails. With breathtaking views of the harbor, this
            bar offers a blend of classic and innovative drinks that capture the
            essence of Hong Kong's vibrant nightlife.
          </p>
          <a href="https://www.instagram.com/argobarhk/">
            Visit ARGO's Instagram
          </a>
        </div>
      </div>
    </div>

    <div className="bar-review">
      <div className="bar-details">
        <img
          src="https://media.timeout.com/images/105898602/image.jpg"
          alt="Most harmless"
        />
        <h4>Most Harmless</h4>
        <p>Quirky Cocktails, Endless Charm</p>
      </div>
      <div className="user-comment">
        <img
          src="https://marketplace.canva.com/EAFBoTcIMBw/2/0/400w/canva-purple-red-cobalt-bright-bold-organic-tiktok-profile-picture-jxjJT5RTc5k.jpg"
          alt="User 3 Profile"
        />
        <div className="comment-details">
          <h5>Noah Anderson </h5>
          <p>Date: May 10, 2023</p>
          <p>
            Decorated bartender Ezra Star moved from the awarded Drink in Boston
            and opened the diminutive Mostly Harmless in Hong Kong. Decked out
            in white tiles, guest's names and the day's menu are written on the
            tiles in magic markers – just one of the many personal touches at
            this intimate bar.
          </p>
          <a href="https://www.instagram.com/mostlyharmlessbar/">
            Visit Most Harmless's Instagram
          </a>
        </div>
      </div>
    </div>

    <div className="bar-review">
      <div className="bar-details">
        <img
          src="https://cdn.shopify.com/s/files/1/0353/9510/9003/files/154887067_112389310795221_8602729582063191823_n_480x480.jpg?v=1672919185"
          alt="Tell Camellia Image"
        />
        <h4>Tell Camellia</h4>
        <p>Bold Flavors, Speakeasy Sophistication</p>
      </div>
      <div className="user-comment">
        <img
          src="https://marketplace.canva.com/EAFIQAKO4Bo/1/0/1600w/canva-cream-aesthetic-rainbow-tiktok-profile-picture-gMK-XJiek8s.jpg"
          alt="User 4 Profile"
        />
        <div className="comment-details">
          <h5>Mia Davis</h5>
          <p>Date: March 29, 2023</p>
          <p>
            Tell Camellia opened in 2019 and managed to rank at No.23 in Asia's
            50 Best Bars 2021 list – that's some seriously quick work. This
            subterranean hangout specialises in tea, with a list overseen by
            industry legend Gagan Gurung.
          </p>
          <p>
            There are two sections to the menu: Teatails, with original
            tea-infused cocktails themed around a specific tea's country of
            origin – The Sri Lanka is a mix of rotovapped ceylon tea, coconut,
            basmati rice, ape amme wine, green algae and rye whiskey. The
            second, T& Tonic section offers teas like Italian almond and
            truffle, or kyoho grape and sakura, blended with gin before being
            redistilled and topped with tonic to create some completely original
            flavour combinations.
          </p>
          <a href="https://www.instagram.com/tellcamellia/">
            Visit Tell Camellia's Instagram
          </a>
        </div>
      </div>
    </div>
  </React.StrictMode>
);
