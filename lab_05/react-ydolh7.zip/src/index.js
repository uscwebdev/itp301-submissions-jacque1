import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>Jacquelyn Li</h1>
    <a href="mailto:youremail@example.com">lijacque@usc.edu</a>
    <h3 id="fav-color">Favorite Color: Orange</h3>
    <h3>
      Favorite Website:
      <a href="https://www.notion.so/product?utm_source=google&utm_campaign=2075789710&utm_medium=80211061601&utm_content=500427479647&utm_term=notion&targetid=kwd-312974742&gclid=CjwKCAjwjaWoBhAmEiwAXz8DBZS-tPZ10n_c0rlvzGkHISxAQVVFfUp-ZNUk5ojFglESHUiUNdp8xhoCO7UQAvD_BwE">
        Notion
      </a>
    </h3>
    <h3>Favorite Activity:</h3>
    <img
      src="https://cdn10.phillymag.com/wp-content/uploads/sites/3/2023/07/thrive-reformer-pilates-900x600-1.jpg"
      alt="pilates"
    />

    <h3>Classes Taken Fall 2023:</h3>
    <ul>
      <li className="class">ITP 301: Web Development</li>
      <li className="class">WRIT 340: Advanced Wrtings for Engineers</li>
      <li className="class">ITP 487: Enterprise Data Management</li>
      <li className="class">ITP 310: Design for UI/UX</li>
    </ul>
    <hr />
  </React.StrictMode>
);
