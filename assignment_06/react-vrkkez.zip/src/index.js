import React from 'react';
import { createRoot } from 'react-dom/client';

import ProductList from './ProductList.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="main">
      <div id="header"> Bluetooth Speakers Shopping Cart | Assignment 6</div>

      <h1>Bluetooth Speakers</h1>

      <div className="container">
        <ProductList
          imageSrc=" https://i.ebayimg.com/images/g/5t0AAOSwmjhcuesH/s-l400.jpg"
          alt="marshall"
          productName="Marshall Acton"
          price="279"
        />
        <ProductList
          imageSrc="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3Wdvkevo4I3M4LF8P2JZft3g8jlIaDEhptaHZF02ODOUhYzP7gli3fbnW8gEZjnhFAx4&usqp=CAU"
          alt="JBL"
          productName="JBL Pulse"
          price="149"
        />
        <ProductList
          imageSrc="https://img.tatacliq.com/images/i7/1348Wx2000H/MP000000008748403_1348Wx2000H_202102100233126.jpeg"
          alt="Bang & Olufsen"
          productName="Bang & Olufsen Beolit"
          price="599"
        />
        <ProductList
          imageSrc="https://www.harmanaudio.com/dw/image/v2/BFND_PRD/on/demandware.static/-/Sites-masterCatalog_Harman/default/dw00921836/HK_AURA_STUDIO3_320_HERO_x4.png?sw=535&sh=535"
          alt="harman kardon"
          productName="Harman Kardon Aura Studio"
          price="199"
        />
      </div>
      <div id="footer">
        <p>@2023 University of Southern California</p>
      </div>
    </div>
  </React.StrictMode>
);
