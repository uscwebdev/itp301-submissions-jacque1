import React from 'react';

export default function ProductList(props) {
  return (
    <div className="thumbnail">
      <img className={props.imageClass} src={props.imageSrc} alt={props.alt} />
      <h4>{props.productName}</h4>
      <p>USD: ${props.price}</p>
    </div>
  );
}
