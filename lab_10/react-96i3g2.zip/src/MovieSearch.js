import React from 'react';
import { useState } from 'react';
import $ from 'jquery';

export default function MovieSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState([]);
  const [numTotalResults, setNumTotalResults] = useState(0);


  function handleFormSubmission(e) {
    e.preventDefault();

    // if searchTerm is empty
    if (!searchTerm) {
      console.log('Search term is empty');
      return;
    }


    $.ajax({
      url: `https://api.themoviedb.org/3/search/movie?api_key=8cad23fa7eed28dc30ecac9ace1a3e4e&query=` +
      searchTerm,
      dataType: 'json',
      success: function (data) {
        setResults(data.results);
        setNumTotalResults(data.total_results);
        // Clear the form field
        setSearchTerm('');
      },
      error: function (error) {
        console.log(error);
      },
    });
  };

  return (
    <div className="container">
      <div className="row">
        <h1 className="col-12 mt-4">Movie Search</h1>
      </div>

      <div className="row">
        <form
          className="col-12"
          id="search-form"
          onSubmit={handleFormSubmission}
        >
          <div className="form-row">
            <div className="col-12 mt-4 col-sm-6 col-md-4 col-lg-3">
              <label htmlFor="search-term" className="sr-only">
                Search:
              </label>

              <input
                type="text"
                id="search-term"
                className="form-control"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.currentTarget.value)}
              />
            </div>
            <div className="col-12 mt-4 col-sm-auto">
              <button type="submit" className="btn btn-primary btn-block">
                Search
              </button>
            </div>
          </div>
        </form>
      </div>

      <div className="row">
        <div className="col-12 mt-4 mb-4">
          Showing{' '}
          <span id="num-results" className="font-weight-bold">
          {results.length}
          </span>{' '}
          of{' '}
          <span id="num-total" className="font-weight-bold">
          {numTotalResults}
          </span>{' '}
          result(s).
        </div>
      </div>
      
      <div id="movie-container" className="row">
        {results.map((movie) => (
          <div key={movie.id} className="text-center my-3 col-6 col-sm-4 col-md-3 col-lg-2">
            <img
              alt={movie.title}
              src={`http://image.tmdb.org/t/p/w500/${movie.poster_path}`}
            />
            <h5>{movie.title}</h5>
            <div>{movie.release_date}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
