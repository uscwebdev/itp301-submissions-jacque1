import React, { useState } from 'react';
import $ from 'jquery';
import Cocktail from './Cocktail';

export default function CocktailSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!searchTerm) {
      console.log('Search term is empty');
      return;
    }

    // Replace the URL with your actual API endpoint
    $.ajax({
      url: `https://www.thecocktaildb.com/api/json/v1/1/search.php?s=${searchTerm}`,
      dataType: 'json',
      success: function (data) {
        setResults(data.drinks || []); 
        setSearchTerm('');
      },
      error: function (error) {
        console.log(error);
      },
    });
  };

  const handleInputChange = (e) => {
    setSearchTerm(e.currentTarget.value);
  };

  return (
    <div className="container">
      <form id="search-form" onSubmit={handleSubmit}>
        <label htmlFor="search-term">Search:</label>
        <input
          type="text"
          className="form-control"
          placeholder="Cocktails on your mind..."
          value={searchTerm}
          onChange={handleInputChange}
          name="name"
          id="name"
        />
        <button type="submit" className="btn-primary">
          Search
        </button>
      </form>

      <div className="results">
        Showing <span id="num-results">{results.length}</span> result(s).
      </div>
      <div className="cocktails-form">
        <div id="cocktail-container">
          {results.map((cocktail) => (
            <Cocktail
              key={cocktail.idDrink}
              image={cocktail.strDrinkThumb}
              name={cocktail.strDrink}
              id={cocktail.idDrink}
            />
          ))}
          </div>
      </div>
    </div>
  );
}
