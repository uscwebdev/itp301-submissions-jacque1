import React from 'react';

export default function SigDrink(props) {
  return (
    <div className="drink">
      <img className={props.imageClass} 
      src={props.imageSrc} alt={props.alt} />
      <h5>{props.drinkName}</h5>
      <h8>{props.ingredient}</h8>
      <div>
        <h7>${props.price}</h7>
      </div>
    </div>
  );
}