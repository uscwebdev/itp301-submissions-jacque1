import React from 'react';

export default function Cocktail({ image, name }) {
  return (
    <article className='cocktail'>
      <div className='img-container'>
        <img src={image} alt={name} />
        <h5>{name}</h5>
      </div>
    </article>
  );
}
