import React from 'react';
import { useRef } from 'react';

function Nav{
  const about = useRef(null);
  const signature = useRef(null);
  const search = useRef(null);
}

const scrollToSection = () => {
  window.scrollTo({
    behavior: "smooth",
  });
};

return (
  <div className="Navbar">
      <ul>
        <li onClick={() => scrollToSection(about)} className="link">
        </li>
        <li onClick={() => scrollToSection(signature)}className="link">
        </li>
        <li onClick={() => scrollToSection(search)} className="link">
        </li>
      </ul>
  </div>
)

export default Nav;