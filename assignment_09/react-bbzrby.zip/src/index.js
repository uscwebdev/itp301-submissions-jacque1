import React, { useRef } from 'react';
import { createRoot } from 'react-dom/client';
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';
import CocktailSearch from './CocktailSearch.js';
import SigDrink from './SignatureList.js';

const root = createRoot(document.querySelector('#root'));
const Nav = () => {
  const aboutRef = useRef(null);
  const signatureRef = useRef(null);
  const searchRef = useRef(null);

  const scrollToSection = (elementRef) => {
    if (elementRef.current) {
      window.scrollTo({
        top: elementRef.current.offsetTop,
        behavior: 'smooth',
      });
    }
  };

  return (
    <React.StrictMode>
      <div>
        <div className="Navbar">
          <ul>
            <li onClick={() => scrollToSection(aboutRef)} className="link">
              About
            </li>
            <li onClick={() => scrollToSection(signatureRef)} className="link">
              Signature
            </li>
            <li onClick={() => scrollToSection(searchRef)} className="link">
              Search
            </li>
          </ul>
        </div>
        <h1>Welcome to Reality Bar</h1>
        <p className="slogan">
          Come find serenity at Reality Bar, where expertly crafted cocktails meet an oasis of calm. Escape the daily grind and rediscover relaxation with our signature drinks and stress-free ambiance.
        </p>
        <hr />

        <div ref={aboutRef}>
          <h2>About US</h2>
          <br />
          <h3>Our Story</h3>
          <p>
            Founded in 2017, Reality Bar emerged as a vision to redefine the bar experience. 
            The decision to open Reality Bar was rooted in a belief that a well-crafted cocktail is not just a drink; it's an experience. In 2017, our founders set out to create a place where the art of mixology would be celebrated, and patrons could immerse themselves in an atmosphere designed for relaxation and enjoyment.
          </p>
          <h3>Our Innovation</h3>
          <p>
            In the heart of our innovation lies the art of blending fruity alcohols to create cocktails that not only tantalize the taste buds but also engage the senses with refreshing scents. We pride ourselves on pushing the boundaries of traditional mixology, ensuring each drink is a masterpiece of flavor and aroma. At Reality Bar, we redefine the cocktail experience, inviting you to indulge in the extraordinary.
          </p>
          <h3>Contact Us</h3>
          <h6 className='email'>  Email: </h6>
          <a href="mailto:youremail@example.com">lijacque@usc.edu</a>
          <h6 className='hours'>  Opening Hours: </h6>
          <p>Tue - Sun: 7pm - 2am</p>
          
        </div>
        <hr/>
        <div ref={signatureRef} >
          <h2>Our Signature</h2>
          <div className="sigdrink">
            <SigDrink
              imageSrc="https://mixthatdrink.com/wp-content/uploads/2009/03/mojito-scaled-1364x2048.jpg"
              alt="mojito"
              drinkName="Mojito"
              ingredient="Rum,Lime,Mint,Soda Water"
              price="10"
            />
            <SigDrink
              imageSrc="https://mixthatdrink.com/wp-content/uploads/2023/06/planters-punch-cocktail-scaled-1365x2048.jpg"
              alt="punch"
              drinkName="Planters Punch"
              ingredient="Rum,Orange/Pineapple Juice,Grenadine,Syrup,Angostura Bitters"
              price="14"
            />
            <SigDrink
              imageSrc="https://mixthatdrink.com/wp-content/uploads/2013/02/french-martini-scaled-scaled-1366x2048.jpg"
              alt="martini"
              drinkName="French Martini"
              ingredient="Vodka,Raspberry Liqueur,Pineapple Juice"
              price="9"
            />
            <SigDrink
              imageSrc="https://mixthatdrink.com/wp-content/uploads/2023/06/bramble-cocktail-scaled-1366x2048.jpg"
              alt="bramble"
              drinkName="Bramble cocktail"
              ingredient="Gin,Lemon Juice,Creme De Mure"
              price="12"
            />
          </div>
        </div>

        <hr />
        <div ref={searchRef}>
          <div>
            <h2>Cocktail Search</h2>
          </div>
            <CocktailSearch />
        </div>
        <br />
        <br />
        <br />
        <div className="footer">
          <h9>All rights reserved. Jacquelyn Li @USC 2023</h9>
        </div>
      </div> 
    </React.StrictMode>
  );
};

root.render(<Nav />);
