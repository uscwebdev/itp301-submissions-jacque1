import React, { useState } from 'react';

export default function ProductList(props) {
  const [count, setCount] = useState(0);

  const handlePlusClick = () => {
    setCount(count + 1);
    props.increaseSubtotal(props.price);
  };

  const handleMinusClick = () => {
    if (count > 0) {
      setCount(count - 1);
      props.decreaseSubtotal(props.price);
    }
  };

  return (
    <div className="thumbnail">
      <img className={props.imageClass} src={props.imageSrc} alt={props.alt} />
      <h4>{props.productName}</h4>
      <p>USD: ${Number(props.price)}</p>
      <div className="counter">
        <button onClick={handleMinusClick}>-</button>
        <span>{count}</span>
        <button onClick={handlePlusClick}>+</button>
      </div>
    </div>
  );
}
