import React from 'react';
import { useState } from 'react';

function PhotoGallery() {
  const [src, setSrc] = useState(
    'https://m.media-amazon.com/images/I/71TD1LoqRdL._AC_SL1050_.jpg'
  );
  const [alt, setAlt] = useState('New Orleans');
  const [caption, setCaption] = useState('Greetings from New Orleans');

//event handler to update photos
  const handleImageChange = (newSrc, newAlt, newCaption) => {
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCaption);
  };

  return (
    <div className="photo-gallery">
      <img src={src} alt={alt} />
      <p>{caption}</p>
      
      <div className="buttons">
        <button
          onClick={() =>
            handleImageChange(
              'https://m.media-amazon.com/images/I/71TD1LoqRdL._AC_SL1050_.jpg',
              'New Orleans',
              'Greetings from New Orleans'
            )
          }
        >
          Image 1
        </button>
        <button
          onClick={() =>
            handleImageChange(
              'https://estatesales.org/thegoods/wp-content/uploads/2020/01/s-l1600.jpg',
              'Los Angeles',
              'Greetings from Los Angeles!'
            )
          }
        >
          Image 2
        </button>
        <button
          onClick={() =>
            handleImageChange(
              'https://img.glyphs.co/img?src=aHR0cHM6Ly9zMy5tZWRpYWxvb3QuY29tL3Jlc291cmNlcy9WaW50YWdlLUdyZWV0aW5ncy1Qb3N0Y2FyZC1HZW5lcmF0b3ItUHJldmlldy0xLmpwZw&q=70&enlarge=true&h=777&w=1200',
              'Alaska',
              'Greetings from Alaska!'
            )
          }
        >
          Image 3
        </button>
        <button
          onClick={() =>
            handleImageChange(
              'https://i.etsystatic.com/16126862/r/il/feeb3e/1532523614/il_570xN.1532523614_p7us.jpg',
              'Minnesota',
              'Greetings from Minnesota!'
            )
          }
        >
          Image 4
        </button>
        <button
          onClick={() =>
            handleImageChange(
              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_iUYpYfqpdLJrmBFdaLaE_0YxGgb6o_y3vg&usqp=CAU',
              'Charleston',
              'Greetings from Charleston!'
            )
          }
        >
          Image 5
        </button>
      </div>
    </div>
  );
}

export default PhotoGallery;
