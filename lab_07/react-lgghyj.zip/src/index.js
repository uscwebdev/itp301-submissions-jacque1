import React from 'react';
import { createRoot } from 'react-dom/client';
import './img.css';
import PhotoGallery from './button.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div>
      <h1>Vintage Postcards Gallery</h1>
      <PhotoGallery />
    </div>
  </React.StrictMode>
);
